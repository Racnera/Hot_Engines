﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;

namespace Sprint_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    enum GameState { MainMenu,Loading,TrackSelection,Time,GameOn}
    
    public partial class MainWindow : Window
    {
        //globals 
        int toggle;
        bool spacebarStatus;
        public int lapNum=0;
        Stopwatch timer;
        public DispatcherTimer gametimer = new DispatcherTimer();
        Tracks t = new Tracks();                                        //calls tracks
        public static int trackNum;                                     //pulls from TrackSelection window
        GameState gameState = new GameState();
        Player p1;                                                      //player 1
        public static string angle ="";                                 //angle debugging
        public static double facing = 0;   
        public static double facingactual = 0;
        public string speed = "";


        public MainWindow()
        {   
            InitializeComponent();                                      //start window
            gameState = GameState.MainMenu;                             //start timer
            gametimer.Tick += Gametimer_Tick;                           //timer update
            gametimer.Interval = new TimeSpan(0, 0, 0, 0, 1000 / 120);  //timer updates at 120fps           
            
        }

        private void Gametimer_Tick(object sender, EventArgs e)
        {
            angle = facing.ToString();                                                //angle debugging
            lblcomputedangle.Content ="Computed Angle:"+facingactual.ToString();
            speed = p1.speed.ToString();
            lblangle.Content = "Angle :" +angle;
            lblspeed.Content = "Speed :" + speed;
            lblGameState.Content = "Game State :" + gameState.ToString();
            lblwalls.Content = ("Track " + Tracks.trackNum.ToString() + "walls");
            lblLaps.Content = ("Lap  " + lapNum + "/3");
            lblposition.Content = (p1.position.X.ToString() +" , " + p1.position.Y.ToString());
            lblLapdata.Content = t.lapNum;
            if (gameState == GameState.MainMenu)                                        //if on the main/start menu
            {
                lblTime.Visibility = Visibility.Hidden;
                instructions.Visibility = Visibility.Hidden;                            //puase menu, shows buttons, hides 
                mainMenu.Visibility = Visibility.Visible;                               
            }
            else if (gameState == GameState.GameOn)
            {
                lblTime.Visibility = Visibility.Visible;
                p1.update(gameScreen);
                t.checkColide(p1);
                timer.Start();
                lblTime.Content = timer.Elapsed;
                instructions.Visibility = Visibility.Hidden;


            }
            else if (gameState == GameState.Loading)
            {
                gameState = GameState.Loading;
                instructions.Visibility = Visibility.Visible;
                timer.Stop();


            }
            if (toggle == 1)
            {
                gameState = GameState.Loading;
                
            }
            else if (toggle == 2)
            {
                gameState = GameState.GameOn;
            }
            else if (toggle == 3)
            {
                gameState = GameState.MainMenu;
            }

            if (Keyboard.IsKeyToggled(Key.P))
            {           
                gameInfo.Visibility = Visibility.Visible;
                
            }
            else { gameInfo.Visibility = Visibility.Hidden; }
                     
            if (Keyboard.IsKeyDown(Key.Q))
               
            {   toggle = 3;
                timer.Stop();
                timer.Reset();
                gameScreen.Children.Clear();
                Tracks.wallPoints.Clear();
                instructions.Visibility = Visibility.Hidden;
                mainMenu.Visibility=Visibility.Visible;
                Keyboard.IsKeyToggled(Key.Space);
                gameState = GameState.MainMenu;
            }
            if (Keyboard.IsKeyDown(Key.Space)
                && !spacebarStatus && gameState==GameState.Loading)
            {   toggle = 2;
                spacebarStatus = true;
                gameState = GameState.GameOn;
                
            }
            if (Keyboard.IsKeyUp(Key.Space))                   
            {
                spacebarStatus = false;
            }



            if (Keyboard.IsKeyDown(Key.Space)
                && !spacebarStatus && gameState == GameState.GameOn)
            {
                spacebarStatus = true;
                gameState = GameState.Loading;
                toggle = 1;
            }
            if (Keyboard.IsKeyUp(Key.Space))
            {
                spacebarStatus = false;
            }
            /*if (Keyboard.IsKeyDown(Key.R))                //debugging
            {
                lapNum = 3;
            }*/
            if (lapNum == 3)
            {
                gameState = GameState.Time;
                MessageBox.Show("You finished the course in " + timer.Elapsed.ToString());
            }
            if (p1.position.X == Tracks.finishPos.X)
            {
                lapNum++;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            gameState = GameState.TrackSelection;
            
            TrackSelection TS = new TrackSelection();
            TS.ShowDialog();
        }       //opens track select window


        private void startGame_Click(object sender, RoutedEventArgs e)
        {
            toggle = 1;
            gameScreen.Children.Clear();
            p1= new Player();
            gameState = GameState.Loading;
            gametimer.Start();
            timer = new Stopwatch();

            switch (trackNum) //switches, allows default and used for testing because I'm lazy. I have to click 3 less buttons to start testing
            {
                case 1:
                    
                    mainMenu.Visibility = Visibility.Hidden;
                    t.Track1(gameScreen);
                    p1.drawPlayer(gameScreen);
                    break;
                case 2:
                    
                    mainMenu.Visibility = Visibility.Hidden;                   
                    t.Track2(gameScreen);
                    p1.drawPlayer(gameScreen);
                    break;
                case 3:
                    
                    mainMenu.Visibility = Visibility.Hidden;
                    t.Track3(gameScreen);
                    p1.drawPlayer(gameScreen);
                    
                    break;
                default:
                    mainMenu.Visibility = Visibility.Hidden;
                    t.Track2(gameScreen);
                    p1.drawPlayer(gameScreen);
                    break;
            } //tracks are called here
        }

        private void Window_LostFocus(object sender, RoutedEventArgs e)
        {
            gameState = GameState.Loading;
        }
    }
}