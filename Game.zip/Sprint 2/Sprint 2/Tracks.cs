﻿///EthanHunter 314243
///5/3/2019
///Tracks and their layouts, 


using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sprint_2
{

    public class Tracks
    {
        /// <summary>
        /// Ethan Hunter
        ///Tracks and their layouts
        /// </summary>
        public int lapNum=0;
        public static int trackNum;
        public static Point finishPos = new Point(500, 725);
        Canvas canvas;
        public Polygon wallinner = new Polygon();
        public Polygon wallouter = new Polygon();
        public Point wallpoint1 = new Point();
        public Point wallpoint2 = new Point();
        public Point wallpoint3 = new Point();
        public Point wallpoint4 = new Point();
        public Point wallpoint5 = new Point();
        public Point wallpoint6 = new Point();
        public Point wallpoint7 = new Point();
        public Point wallpoint8 = new Point();
        public static PointCollection wallPoints = new PointCollection(); //static for on-screen data
        public Point wallpoint1out = new Point();
        public Point wallpoint2out = new Point();
        public Point wallpoint3out = new Point();
        public Point wallpoint4out = new Point();
        public Point wallpoint5out = new Point();
        public Point wallpoint6out = new Point();
        public Point wallpoint7out = new Point();
        public Point wallpoint8out = new Point();
        public PointCollection wallPointsout = new PointCollection();    
        public Polygon finish = new Polygon();
        Point finTL = new Point(500, 700);
        Point finBL = new Point(500, 800);
        Point finTR = new Point(525, 700);
        Point finBR = new Point(525, 800);
        PointCollection finPoint = new PointCollection();
        

        /// <summary>
        /// Austin McKee
        /// 
        /// Each track is points and polygons used for walls
        /// </summary>
        /// <param name="c">
        /// same for all tracks, c = gameScreen in mainwindow.xaml.cs
        /// </param>
        /// AUSTIN
        public void Track1(Canvas c)
        {
            canvas = c;

            Polygon OutsideT = new Polygon();
            Point OBL = new Point(300, 825);
            Point OMML = new Point(300, 500);
            Point OML = new Point(100, 500);
            Point OTL = new Point(100, 100);
            Point OTR = new Point(900, 100);
            Point OMR = new Point(900, 500);
            Point OMMR = new Point(700, 500);
            Point OBR = new Point(700, 825);
            PointCollection OutsideTP = new PointCollection();
            OutsideTP.Add(OBL);
            OutsideTP.Add(OMML);
            OutsideTP.Add(OML);
            OutsideTP.Add(OTL);
            OutsideTP.Add(OTR);
            OutsideTP.Add(OMR);
            OutsideTP.Add(OMMR);
            OutsideTP.Add(OBR);
            OutsideT.Points = OutsideTP;
            OutsideT.Fill = Brushes.Purple;
            canvas.Children.Add(OutsideT);
            Polygon InsideT = new Polygon();
            Point BL = new Point(400, 725);
            Point MML = new Point(400, 400);
            Point ML = new Point(200, 400);
            Point TL = new Point(200, 200);
            Point TR = new Point(800, 200);
            Point MR = new Point(800, 400);
            Point MMR = new Point(600, 400);
            Point BR = new Point(600, 725);
            PointCollection InsideTP = new PointCollection();
            InsideTP.Add(BL);
            InsideTP.Add(MML);
            InsideTP.Add(ML);
            InsideTP.Add(TL);
            InsideTP.Add(TR);
            InsideTP.Add(MR);
            InsideTP.Add(MMR);
            InsideTP.Add(BR);
            InsideT.Points = InsideTP;
            InsideT.Fill = Brushes.Black;
            canvas.Children.Add(InsideT);
            Rectangle finish = new Rectangle();
            finish.Height = 100;
            finish.Width = 25;
            finish.Fill = Brushes.White;
            canvas.Children.Add(finish);
            Canvas.SetTop(finish, 725);
            Canvas.SetLeft(finish, 500);

        }
        //ETHAN
        public void Track2(Canvas c)

        {
            wallpoint1out = new Point(300, 250);//inner wall
            wallpoint2out = new Point(300, 800);
            wallpoint4out = new Point(1100, 250);
            wallpoint3out = new Point(1100, 800);
            wallpoint5out = new Point(1100, 800);
            wallpoint6out = new Point(1100, 800);
            wallPointsout.Add(wallpoint1out);
            wallPointsout.Add(wallpoint2out);
            wallPointsout.Add(wallpoint3out);
            wallPointsout.Add(wallpoint4out);
            wallouter.Points = (wallPointsout);
            wallouter.Stroke = Brushes.Green;
            wallouter.StrokeThickness = 5;
            wallouter.Fill = Brushes.Black;
            c.Children.Add(wallouter);


            wallpoint1 = new Point(400, 350);//inner wall
            wallpoint2 = new Point(400, 700);
            wallpoint4 = new Point(1000, 350);
            wallpoint3 = new Point(1000, 700);
            wallpoint5 = new Point(1000, 700);
            wallpoint6 = new Point(1000, 700);
            wallPoints.Add(wallpoint1);
            wallPoints.Add(wallpoint2);
            wallPoints.Add(wallpoint3);
            wallPoints.Add(wallpoint4);
            wallinner.Points = (wallPoints);
            wallinner.Fill = Brushes.Green;
            c.Children.Add(wallinner);

            finPoint.Add(finTL);
            finPoint.Add(finTR);
            finPoint.Add(finBL);
            finPoint.Add(finBR);
            finish.Points = finPoint;
            finish.Fill = Brushes.White;
            c.Children.Add(finish);

        }
        //AUSTIN
        public void Track3(Canvas c)
        {
            Polygon OutsideU = new Polygon(); //outer wall
            Point OTL = new Point(125, 50);
            wallpoint1out = OTL;
            Point OTMR = new Point(425, 50);
            wallpoint2out = OTMR;
            Point OML = new Point(425, 525);
            wallpoint3out = OML;
            Point OMR = new Point(625, 525);
            wallpoint4out = OMR;
            Point OTML = new Point(625, 50);
            wallpoint5out = OTML;
            Point OTR = new Point(925, 50);
            wallpoint6out = OTR;
            Point OBR = new Point(925, 825);
            wallpoint7out = OBR;
            Point OBL = new Point(125, 825);
            wallpoint8out = OBL;
            PointCollection OutsideUpoints = new PointCollection();
            OutsideUpoints.Add(OTL);
            OutsideUpoints.Add(OTMR);
            OutsideUpoints.Add(OML);
            OutsideUpoints.Add(OMR);
            OutsideUpoints.Add(OTML);
            OutsideUpoints.Add(OTR);
            OutsideUpoints.Add(OBR);
            OutsideUpoints.Add(OBL);
            OutsideU.Points = OutsideUpoints;           
            OutsideU.Stroke = Brushes.Green;
            OutsideU.StrokeThickness = 5;
            OutsideU.Fill = Brushes.Black;
            c.Children.Add(OutsideU);

            Polygon insideU = new Polygon();
            Point TL = new Point(225, 150);
            wallpoint1 = TL;
            Point TMR = new Point(325, 150);
            wallpoint2 = TMR;
            Point ML = new Point(325, 625);
            wallpoint3 = ML;
            Point MR = new Point(725, 625);
            wallpoint4 = MR;
            Point TML = new Point(725, 150);
            wallpoint5 = TML;
            Point TR = new Point(825, 150);
            wallpoint6 = TR;
            Point BR = new Point(825, 725);
            wallpoint7 = TML;
            Point BL = new Point(225, 725);
            wallpoint8 = BL;


            PointCollection InsideUpoints = new PointCollection();
            InsideUpoints.Add(TL);
            InsideUpoints.Add(TMR);
            InsideUpoints.Add(ML);
            InsideUpoints.Add(MR);
            InsideUpoints.Add(TML);
            InsideUpoints.Add(TR);
            InsideUpoints.Add(BR);
            InsideUpoints.Add(BL);
            insideU.Points = InsideUpoints;
            insideU.Fill = Brushes.Green;
            c.Children.Add(insideU);
            wallPoints = InsideUpoints;
        }
        /// <summary>
        /// Ethan Hunter
        /// </summary>
        /// <param name="p"> player, p1 </param>
       
        public void checkColide(Player p)
        {
            switch (trackNum)
            {
                case 1:
                if ((p.position.X + 22 >= wallpoint1.X &&
                p.position.Y + 28 >= wallpoint1.Y &&
                p.position.Y + 28 <= wallpoint2.Y &&
                p.position.X + 22 <= wallpoint4.X)
                ||
                (p.position.X >= wallpoint1.X &&
                p.position.Y >= wallpoint1.Y &&
                p.position.Y <= wallpoint2.Y &&
                p.position.X <= wallpoint4.X))
            {
                p.speed = 2;
            }
                    break;


                case 2:
                    if ((p.position.X + 22 >= wallpoint1.X &&
             p.position.Y + 28 >= wallpoint1.Y &&
             p.position.Y + 28 <= wallpoint2.Y &&
             p.position.X + 22 <= wallpoint4.X)
             ||
             (p.position.X >= wallpoint1.X &&
             p.position.Y >= wallpoint1.Y &&
             p.position.Y <= wallpoint2.Y &&
             p.position.X <= wallpoint4.X))
                    {
                        p.speed = 2;
                    }
                    if ((p.position.X + 22 <= wallpoint1out.X ||    //outer wall
             p.position.Y + 28 <= wallpoint1out.Y ||
             p.position.Y + 28 >= wallpoint3out.Y ||
             p.position.X + 22 >= wallpoint3out.X
             )
             ||
             (p.position.X <= wallpoint1out.X ||
             p.position.Y <= wallpoint1out.Y ||
             p.position.Y >= wallpoint3out.Y ||
             p.position.X >= wallpoint3out.X))
                    {
                        p.speed = 2;
                    }
                    if (p.position.X <= finTL.X &&
                        p.position.X >= finTR.X &&
                        p.position.Y <= finBL.Y &&
                        p.position.Y >= finBR.Y
                        )
                    {
                        //MainWindow.lapNum++;
                    }


                    break;
                case 3:// collision for track 3, this is the worst way of doing it I think, but i knew it could be done this way
                    if 
                        ((p.position.X + 22 >= wallpoint1.X && //inner wall
             p.position.Y + 28 >= wallpoint1.Y &&
             p.position.Y + 28 <= wallpoint8.Y &&
             p.position.X + 22 <= wallpoint6.X        
             )
             ||
             (p.position.X >= wallpoint1.X &&
             p.position.Y >= wallpoint1.Y &&
             p.position.Y <= wallpoint8.Y &&
             p.position.X <= wallpoint6.X))
                    {
                        if ((p.position.X + 22 >= wallpoint2.X &&
                            p.position.Y + 28 >= wallpoint2.Y &&
                            p.position.Y + 28 <= wallpoint3.Y &&
                            p.position.X + 22 <= wallpoint5.X)
                            ||
                            (p.position.X >= wallpoint2.X &&
                            p.position.Y >= wallpoint2.Y &&
                            p.position.Y <= wallpoint3.Y &&
                            p.position.X <= wallpoint5.X))
                        {
                            p.speed = 5;
                        }
                        else { p.speed = 2; } 
                    }

                    if ((p.position.X + 22 <= wallpoint1out.X ||    //outer wall
             p.position.Y + 28 <= wallpoint1out.Y ||
             p.position.Y + 28 >= wallpoint8out.Y ||
             p.position.X + 22 >= wallpoint6out.X
             )
             ||
             (p.position.X <= wallpoint1out.X ||
             p.position.Y <= wallpoint1out.Y ||
             p.position.Y >= wallpoint8out.Y ||
             p.position.X >= wallpoint6out.X))
                    {
                        
                        p.speed = 2; 
                    }
                    if ((p.position.X + 22 >= wallpoint2out.X &&
                            p.position.X + 22 <= wallpoint4out.X&&
                            p.position.Y + 28 >= wallpoint2out.Y &&
                            p.position.Y +28<=wallpoint4out.Y
                            )
                            ||
                            (p.position.X >= wallpoint2out.X &&
                            p.position.X <= wallpoint5out.X &&
                            p.position.Y >= wallpoint2out.Y &&
                            p.position.Y <= wallpoint4out.Y))
                        {
                            p.speed = 2;
                        }
                    return;


                default: goto case 2;
                    /*if ((p.position.X + 22 >= wallpoint1.X &&
                p.position.Y + 28 >= wallpoint1.Y &&
                p.position.Y + 28 <= wallpoint2.Y &&
                p.position.X + 22 <= wallpoint4.X)
                ||
                (p.position.X >= wallpoint1.X &&
                p.position.Y >= wallpoint1.Y &&
                p.position.Y <= wallpoint2.Y &&
                p.position.X <= wallpoint4.X))
                    {
                        p.speed = 2;
                    }
                    break;*/



            }

            

        }
    }
}
