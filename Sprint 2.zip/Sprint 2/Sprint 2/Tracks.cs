﻿///EthanHunter 314243
///5/3/2019
///Tracks and their layouts, 


using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sprint_2
{

    public class Tracks
    {
        /// <summary>
        /// Ethan Hunter
        ///Tracks and their layouts
        /// </summary>
        Canvas canvas;
        public Polygon wallinner = new Polygon();
        public Polygon wallouter = new Polygon();
        public Point wallpoint1 = new Point();
        public Point wallpoint2 = new Point();
        public Point wallpoint3 = new Point();
        public Point wallpoint4 = new Point();
        public Point wallpoint5 = new Point();
        public Point wallpoint6 = new Point();
        public PointCollection wallPoints = new PointCollection();
        public Point wallpoint1out = new Point();
        public Point wallpoint2out = new Point();
        public Point wallpoint3out = new Point();
        public Point wallpoint4out = new Point();
        Rectangle startLine = new Rectangle();
        
        /// <summary>
        /// Austin McKee
        /// 
        /// Each track is points and polygons used for walls
        /// </summary>
        /// <param name="c">
        /// same for all tracks, c = gameScreen in mainwindow.xaml.cs
        /// </param>
        public void Track1(Canvas c)
        {
            canvas = c;

            Polygon TrackOneInsideOne = new Polygon();
            Point InsideOne1 = new Point(300, 200);
            Point InsideOne2 = new Point(900, 200);
            Point InsideOne3 = new Point(1100, 400);
            Point InsideOne4 = new Point(1100, 600);
            Point InsideOne5 = new Point(900, 800);
            Point InsideOne6 = new Point(300, 800);
            Point InsideOne7 = new Point(100, 600);
            Point InsideOne8 = new Point(100, 400);
            PointCollection InsideOne = new PointCollection();
            InsideOne.Add(InsideOne1);
            InsideOne.Add(InsideOne2);
            InsideOne.Add(InsideOne3);
            InsideOne.Add(InsideOne4);
            InsideOne.Add(InsideOne5);
            InsideOne.Add(InsideOne6);
            InsideOne.Add(InsideOne7);
            InsideOne.Add(InsideOne8);
            TrackOneInsideOne.Points = InsideOne;
            TrackOneInsideOne.Stroke = Brushes.Green;
            TrackOneInsideOne.StrokeThickness = 5;
            c.Children.Add(TrackOneInsideOne);

        }
        public void Track2(Canvas c)
        {
            /*canvas = c;
            wall1.Height = 600;
            wall1.Width = 800;
            wall1Pos.Y = 100;
            wall1Pos.X = 200;
            wall1.Fill = Brushes.Green;
            canvas.Children.Add(wall1);
            Canvas.SetLeft(wall1, wall1Pos.X);
            Canvas.SetTop(wall1, wall1Pos.Y);*/

            

            wallpoint1 = new Point(400, 350);//inner wall
            wallpoint2 = new Point(400, 700);
            wallpoint4 = new Point(1000, 350);
            wallpoint3 = new Point(1000, 700);
            wallpoint5 = new Point(1000, 700);
            wallpoint6 = new Point(1000, 700);
            wallPoints.Add(wallpoint1);
            wallPoints.Add(wallpoint2);
            wallPoints.Add(wallpoint3);
            wallPoints.Add(wallpoint4);
            wallinner.Points = (wallPoints);
            wallinner.Fill = Brushes.Green;
            c.Children.Add(wallinner);
        }
        public void Track3(Canvas c)
        {
            
        }

        /// <summary>
        /// Ethan Hunter
        /// </summary>
        /// <param name="p"></param>
        public void checkColide(Player p)
        {
            if((p.position.X+22>=wallpoint1.X  &&
                p.position.Y+28>=wallpoint1.Y &&
                p.position.Y + 28 <= wallpoint2.Y &&
                p.position.X +22 <= wallpoint4.X)
                ||
                (p.position.X >= wallpoint1.X &&
                p.position.Y >= wallpoint1.Y &&
                p.position.Y <= wallpoint2.Y &&
                p.position.X <= wallpoint4.X))   
            {               
                p.speed = 2;
            }
        }
    }

}
